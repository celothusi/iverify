class AppTheme {
  AppTheme._();

  //     ======================= Font Family =======================     //
  static const String poppins = 'Poppins';
}
