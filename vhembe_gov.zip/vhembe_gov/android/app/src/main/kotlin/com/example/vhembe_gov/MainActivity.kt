package com.example.vhembe_gov

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
